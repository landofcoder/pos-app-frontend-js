// @flow
import * as types from '../constants/root';

export function cashPlaceOrderAction() {
  return {
    type: types.CASH_CHECKOUT_PLACE_ORDER_ACTION
  };
}
