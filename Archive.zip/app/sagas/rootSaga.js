// @flow
import { all, call, put, select, takeEvery } from 'redux-saga/effects';
import * as types from '../constants/root';
import {
  addProductToQuote,
  addShippingInformationService,
  createGuestCartService,
  createInvoiceService,
  createShipmentService,
  placeCashOrderService
} from './services/CartService';
import {
  getDetailProductBundleService,
  getDetailProductConfigurableService,
  getDetailProductGroupedService,
  getProductsService,
  searchProductService
} from './services/ProductService';
import {
  getCustomerCartTokenService,
  searchCustomer
} from './services/CustomerService';
import { createCustomerCartService } from './services/CustomerCartService';
import { getSystemConfigService } from './services/CommonService';
import {
  handleProductType,
  reformatConfigurableProduct
} from '../common/product';
import { adminToken } from '../params';
import {
  getDefaultShippingMethod,
  getDefaultPaymentMethod
} from './common/orderSaga';
import { calcPrice } from '../common/productPrice';

const cartCurrent = state => state.mainRd.cartCurrent.data;
const cartCurrentToken = state => state.mainRd.cartCurrent.customerToken;
const cartId = state => state.mainRd.cartCurrent.cartId;
const cartIsGuestCustomer = state => state.mainRd.cartCurrent.isGuestCustomer;
const optionValue = state => state.mainRd.productOption.optionValue;
const customer = state => state.mainRd.cartCurrent.customer;

/**
 * Create quote function
 * @returns {IterableIterator<*>}
 */
function* cashCheckout() {
  // Show cash modal
  yield put({ type: types.UPDATE_SHOW_CASH_MODAL, payload: true });
  // Show cash loading pre order
  yield put({ type: types.UPDATE_CASH_LOADING_PREPARING_ORDER, payload: true });

  // Add product item to cart
  const cartCurrentResult = yield select(cartCurrent);
  const defaultShippingMethod = yield getDefaultShippingMethod();

  const {
    cartId,
    isGuestCustomer,
    customerToken
  } = yield getCustomerCartToken();

  yield all(
    cartCurrentResult.map(item =>
      call(addProductToQuote, cartId, item.sku, {
        isGuestCustomer,
        customerToken
      })
    )
  );

  // Add shipping and get detail order
  const response = yield call(addShippingInformationService, cartId, {
    isGuestCustomer,
    customerToken,
    defaultShippingMethod
  });
  yield put({
    type: types.RECEIVED_ORDER_PREPARING_CHECKOUT,
    payload: response
  });

  // Hide cash loading pre order
  yield put({
    type: types.UPDATE_CASH_LOADING_PREPARING_ORDER,
    payload: false
  });
}

/**
 * Create cart token for guest or customer user
 * @returns {Generator<any, {isGuestCustomer: *, customerToken: *, cardId: *}>}
 */
function* getCustomerCartToken() {
  const customerRdResult = yield select(customer);
  let isGuestCustomer = true;
  if (customerRdResult !== null) {
    // Customer logged
    isGuestCustomer = false;
  }

  let cartId;
  let customerToken;

  // Update isGuestCustomer to reducer
  yield updateIsGuestCustomer(isGuestCustomer);

  if (isGuestCustomer) {
    // Get guest cart customer
    cartId = yield call(createGuestCartService);
  } else {
    // Create customer cart
    const customerId = customerRdResult.id;
    customerToken = yield call(getCustomerCartTokenService, customerId);
    cartId = yield call(createCustomerCartService, customerToken);
  }

  // Update cartId to reducer
  yield put({ type: types.UPDATE_CART_ID_TO_CURRENT_CART, payload: cartId });

  // Update cart token to current quote
  yield put({
    type: types.UPDATE_CART_TOKEN_TO_CURRENT_CART,
    payload: customerToken
  });

  return {
    cartId,
    isGuestCustomer,
    customerToken
  };
}

/**
 * Update isGuestCustomer to reducer
 * @returns {Generator<<"PUT", PutEffectDescriptor<{payload: *, type: *}>>, *>}
 */
function* updateIsGuestCustomer(isGuestCustomer) {
  yield put({
    type: types.UPDATE_IS_GUEST_CUSTOMER_CURRENT_CART,
    payload: isGuestCustomer
  });
}

/**
 * Get default product
 * @returns {Generator<*, *>}
 */
function* getDefaultProduct() {
  // Start loading
  yield put({ type: types.UPDATE_MAIN_PRODUCT_LOADING, payload: true });

  const response = yield call(getProductsService);
  const productResult = response.data ? response.data.products.items : [];
  yield put({ type: types.RECEIVED_PRODUCT_RESULT, payload: productResult });

  // Stop loading
  yield put({ type: types.UPDATE_MAIN_PRODUCT_LOADING, payload: false });
}

/**
 * Cash place order
 * @returns {Generator<<"CALL", CallEffectDescriptor<RT>>, *>}
 */
function* cashCheckoutPlaceOrder() {
  // Start cash place order loading
  yield put({ type: types.UPDATE_CASH_PLACE_ORDER_LOADING, payload: true });

  const cartCurrentTokenResult = yield select(cartCurrentToken);
  const isGuestCustomer = yield select(cartIsGuestCustomer);
  const cartIdResult = yield select(cartId);

  const defaultShippingMethod = yield getDefaultShippingMethod();
  // Default payment
  const defaultPaymentMethod = yield getDefaultPaymentMethod();

  const orderId = yield call(placeCashOrderService, cartCurrentTokenResult, {
    cartIdResult,
    isGuestCustomer,
    customerToken: cartCurrentTokenResult,
    defaultShippingMethod,
    defaultPaymentMethod
  });

  // Create Receipt
  yield call(createInvoiceService, adminToken, orderId);

  // Create shipment
  yield call(createShipmentService, adminToken, orderId);

  // Place order success, let show receipt and copy current cart to cartForReceipt
  yield put({ type: types.PLACE_ORDER_SUCCESS });

  // Select cart current
  const cartCurrentResponse = yield select(cartCurrent);
  console.log('cart current response:', JSON.stringify(cartCurrentResponse));

  // Stop cash loading order loading
  yield put({ type: types.UPDATE_CASH_PLACE_ORDER_LOADING, payload: false });
}

/**
 * Search action
 * @param searchValue
 * @returns {Generator<<"CALL", CallEffectDescriptor<RT>>, *>}
 */
function* search(searchValue) {
  const searchResult = yield call(searchProductService, searchValue);
  console.log('search result:', searchResult);
}

/**
 * Get detail product configurable
 * @param payload
 * @returns {Generator<<"CALL", CallEffectDescriptor<RT>>, *>}
 */
function* getDetailProductConfigurable(payload) {
  yield startLoadingProductOption();

  const productDetail = yield call(
    getDetailProductConfigurableService,
    payload
  );

  const productDetailSingle = productDetail.data.products.items[0];
  const productDetailReFormat = yield handleProductType(productDetailSingle);
  yield receivedProductOptionValue(productDetailReFormat);

  yield getDetailProductEndTask();
}

/**
 * Get detail bundle product
 * @returns {Generator<<"CALL", CallEffectDescriptor<RT>>, *>}
 */
function* getDetailBundleProduct(payload) {
  yield startLoadingProductOption();

  const productDetail = yield call(getDetailProductBundleService, payload);
  const productDetailSingle = productDetail.data.products.items[0];
  const productDetailReFormat = yield handleProductType(productDetailSingle);
  yield receivedProductOptionValue(productDetailReFormat);

  yield getDetailProductEndTask();
}

/**
 *
 * @returns {Generator<*, *>}
 */
function* getDetailGroupedProduct(payload) {
  yield startLoadingProductOption();

  const productDetail = yield call(getDetailProductGroupedService, payload);
  const products = productDetail.data.products.items[0];
  yield receivedProductOptionValue(products);

  yield getDetailProductEndTask();
}

/**
 *
 * @returns {Generator<<"PUT", PutEffectDescriptor<{payload: boolean, type: *}>>, *>}
 */
function* startLoadingProductOption() {
  // Start loading for get product detail and option
  yield put({ type: types.UPDATE_IS_LOADING_PRODUCT_OPTION, payload: true });
}

/**
 *
 * @returns {Generator<<"PUT", PutEffectDescriptor<{payload: boolean, type: *}>>, *>}
 */
function* getDetailProductEndTask() {
  // Set showProductOption to true
  // yield put({ type: types.UPDATE_IS_SHOWING_PRODUCT_OPTION, payload: true });

  // Stop loading
  yield put({ type: types.UPDATE_IS_LOADING_PRODUCT_OPTION, payload: false });
}

/**
 * On config select on change
 * @returns {Generator<*, *>}
 */
function* onConfigurableSelectOnChange(payload) {
  // Update change to reducer
  yield put({ type: types.UPDATE_CONFIGURABLE_PRODUCT_OPTION, payload });

  const optionValueRd = yield select(optionValue);
  const productDetailReFormat = yield reformatConfigurableProduct(
    optionValueRd,
    false
  );
  yield receivedProductOptionValue(productDetailReFormat);
  // console.log('product detail reformat:', productDetailReFormat);
}

/**
 * Received product option value
 * @param productDetailReFormat
 * @returns {Generator<<"PUT", PutEffectDescriptor<{payload: *, type: *}>>, *>}
 */
function* receivedProductOptionValue(productDetailReFormat) {
  // Set product detail to productOption->optionValue
  yield put({
    type: types.UPDATE_PRODUCT_OPTION_VALUE,
    payload: productDetailReFormat
  });
}

/**
 * Search customer action
 * @param payload
 * @returns {Generator<<"CALL", CallEffectDescriptor>|<"PUT", PutEffectDescriptor<{payload: boolean, type: *}>>, *>}
 */
function* getSearchCustomer(payload) {
  // Start search loading
  yield put({ type: types.UPDATE_IS_LOADING_SEARCH_CUSTOMER, payload: true });

  const searchResult = yield call(searchCustomer, payload);

  yield put({
    type: types.RECEIVED_CUSTOMER_SEARCH_RESULT,
    searchResult
  });

  // Stop search loading
  yield put({ type: types.UPDATE_IS_LOADING_SEARCH_CUSTOMER, payload: false });
}

/**
 * Add to cart function
 * @param payload
 * @returns {Generator<<"PUT", PutEffectDescriptor<{payload: *, type: *}>>|<"SELECT", SelectEffectDescriptor>, *>}
 */
function* addToCart(payload) {
  // Find sky if exits sku, then increment qty
  const listCartCurrent = yield select(cartCurrent);
  const product = Object.assign({}, payload.payload);
  const productSku = product.sku;

  // Add default pos_qty, if it does not exists
  if (!product.pos_qty) {
    product.pos_qty = 1;
  }

  let found = 0;
  let foundItem = null;
  let foundIndex = 0;

  // Find exists product to update qty and add pos_qty if have no exists
  for (let i = 0; i < listCartCurrent.length; i += 1) {
    const item = listCartCurrent[i];

    // Update exists product with qty increment
    if (item.sku === productSku) {
      foundIndex = i;
      found = 1;
      foundItem = item;
    }
  }

  if (found === 1) {
    // Edit
    yield put({
      type: types.UPDATE_ITEM_CART,
      payload: { index: foundIndex, item: foundItem }
    });

    // todo: NEED UPDATE QTY AFTER RUN calcPrice
    console.log('found item:', foundItem);
    yield calcPrice(foundItem);
  } else {
    // Update product price
    const productAssign = yield calcPrice(product);

    // Add new
    yield put({ type: types.ADD_ITEM_TO_CART, payload: productAssign });
  }
}

/**
 * Get pos general config
 * @returns {Generator<<"CALL", CallEffectDescriptor>, void, ?>}
 */
function* getPostConfigGeneralConfig() {
  // Start loading
  yield put({ type: types.UPDATE_IS_LOADING_SYSTEM_CONFIG, payload: true });

  const configGeneralResponse = yield call(getSystemConfigService);
  yield put({
    type: types.RECEIVED_POST_GENERAL_CONFIG,
    payload: configGeneralResponse
  });

  // Stop loading
  yield put({ type: types.UPDATE_IS_LOADING_SYSTEM_CONFIG, payload: false });
}

/**
 * Default root saga
 * @returns {Generator<<"FORK", ForkEffectDescriptor<RT>>, *>}
 */
function* rootSaga() {
  yield takeEvery(types.CASH_CHECKOUT_ACTION, cashCheckout);
  yield takeEvery(types.SEARCH_ACTION, search);
  yield takeEvery(types.GET_DEFAULT_PRODUCT, getDefaultProduct);
  yield takeEvery(
    types.CASH_CHECKOUT_PLACE_ORDER_ACTION,
    cashCheckoutPlaceOrder
  );
  yield takeEvery(
    types.GET_DETAIL_PRODUCT_CONFIGURABLE,
    getDetailProductConfigurable
  );
  yield takeEvery(
    types.ON_CONFIGURABLE_SELECT_ONCHANGE,
    onConfigurableSelectOnChange
  );
  yield takeEvery(types.GET_DETAIL_PRODUCT_BUNDLE, getDetailBundleProduct);
  yield takeEvery(types.GET_DETAIL_PRODUCT_GROUPED, getDetailGroupedProduct);
  yield takeEvery(types.SEARCH_CUSTOMER, getSearchCustomer);
  yield takeEvery(types.ADD_TO_CART, addToCart);
  yield takeEvery(types.GET_POS_GENERAL_CONFIG, getPostConfigGeneralConfig);
}

export default rootSaga;
