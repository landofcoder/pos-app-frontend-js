// import mainRd from '../../app/reducers/mainRd';
// import {
//   INCREMENT_COUNTER,
//   DECREMENT_COUNTER
// } from '../../app/actions/counter';
//
// describe('reducers', () => {
//   describe('counter', () => {
//     it('should handle initial state', () => {
//       expect(mainRd(undefined, {})).toMatchSnapshot();
//     });
//
//     it('should handle INCREMENT_COUNTER', () => {
//       expect(mainRd(1, { type: INCREMENT_COUNTER })).toMatchSnapshot();
//     });
//
//     it('should handle DECREMENT_COUNTER', () => {
//       expect(mainRd(1, { type: DECREMENT_COUNTER })).toMatchSnapshot();
//     });
//
//     it('should handle unknown action type', () => {
//       expect(mainRd(1, { type: 'unknown' })).toMatchSnapshot();
//     });
//   });
// });
